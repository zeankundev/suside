## Changelog
- New: Integrated Terminal
- Fixed: HTML Preview, When you link css files in your HTML page
- Improvement: App size
- Improvement: UI 
- Fixed: Short cut keys for zoomin and zoomout